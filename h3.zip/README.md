# Data-Mining-CC5206
Data mining proyect using Block's dataset.
